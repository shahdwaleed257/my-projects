<?php

namespace news;

class User
{

    public $name;
    public $email;
}
